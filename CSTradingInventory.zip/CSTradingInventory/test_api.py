import requests
url = "https://csfloat.com/api/v1/items"
response = requests.get(url)
data = response.json()
print(data[0])